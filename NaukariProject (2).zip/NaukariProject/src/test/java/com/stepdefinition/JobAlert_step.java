package com.stepdefinition;

import com.pages.JobAlert_Main;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class JobAlert_step {
	JobAlert_Main jb=new JobAlert_Main();
	@Given("^user launched the chromebrowser$")
	public void user_launched_the_chromebrowser() throws Throwable {
	 jb.launchChrome();
	}

	@When("^user opens naukrihomepage$")
	public void user_opens_naukrihomepage() throws Throwable {
	  jb.url();
	   jb.loginn();
	}

	@Then("^Click on jobs and move to create job alert$")
	public void click_on_jobs_and_move_to_create_job_alert() throws Throwable {
	 jb.clickonjobalert();
	}

	@When("^alert page is opened enter all the required fields$")
	public void alert_page_is_opened_enter_all_the_required_fields() throws Throwable {
	   jb.enterdata();
	}

	@When("^click on create job alert$")
	public void click_on_create_job_alert() throws Throwable {
	  jb.createjobalert();
	}
}
