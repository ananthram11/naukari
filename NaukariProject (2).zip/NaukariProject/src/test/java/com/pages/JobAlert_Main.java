package com.pages;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class JobAlert_Main {
	static WebDriver driver;
	public void launchChrome()
	{
		System.setProperty("webdriver.chrome.driver","C:\\java Example programs\\NaukariProject\\src\\test\\resources\\drivers\\chromedriver.exe");
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	public void url()
	{
		driver.get("https://www.naukri.com/");
		String windowTitle= getCurrentWindowTitle();
		String mainWindow = getMainWindowHandle(driver);
		Assert.assertTrue(closeAllOtherWindows(mainWindow));
		Assert.assertTrue(windowTitle.contains("Jobs - Recruitment"));
	}
		
	public String getMainWindowHandle(WebDriver driver) {
		return driver.getWindowHandle();
	}

	public String getCurrentWindowTitle() {
		String windowTitle = driver.getTitle();
		return windowTitle;
	}
	
	//To close all the other windows except the main window.
	public static boolean closeAllOtherWindows(String openWindowHandle) {
		Set<String> allWindowHandles = driver.getWindowHandles();
		for (String currentWindowHandle : allWindowHandles) {
			if (!currentWindowHandle.equals(openWindowHandle)) {
				driver.switchTo().window(currentWindowHandle);
				driver.close();
			}
		}
		
		driver.switchTo().window(openWindowHandle);
		if (driver.getWindowHandles().size() == 1)
			return true;
		else
			return false;
	}
	public void loginn() throws IOException
	{
		driver.findElement(By.xpath("//*[@id=\"login_Layer\"]/div")).click();
		
		
		driver.findElement(By.id("eLoginNew")).sendKeys("tejaswini.m481@gmail.com");
		driver.findElement(By.id("pLogin")).sendKeys("tejaswini@24");
		driver.findElement(By.xpath("//*[@id=\"lgnFrmNew\"]/div[9]/button")).click();
	}
	public void clickonjobalert() {
		WebElement a =driver.findElement(By.xpath("/html/body/div[1]/div/div/ul[1]/li[1]/a"));
		WebElement b =driver.findElement(By.xpath("/html/body/div[1]/div/div/ul[1]/li[1]/div/ul[1]/li[3]/a"));
		Actions act = new Actions(driver);
		act.moveToElement(a);
		act.moveToElement(b).click().build().perform();
		Set<String>winHandles2=driver.getWindowHandles();
		 
	    for(String winHandle:winHandles2)
	    {
	    	driver.switchTo().window(winHandle);
	    	
	    }
	}
	public void  enterdata() {
		driver.findElement(By.id("Sug_kwdsugg")).sendKeys("java developer");
		driver.findElement(By.xpath("//*[@id=\"Sug_locsugg\"]")).sendKeys("Hyderabad");
		driver.findElement(By.xpath("//*[@id=\"cjaExp\"]")).click();
		WebElement c =driver.findElement(By.xpath("//*[@id=\"~3\"]"));
		Actions act = new Actions(driver);
		act.moveToElement(c).click().build().perform();
		driver.findElement(By.xpath("//*[@id=\"cjaMinSal\"]")).click();
		WebElement d =driver.findElement(By.xpath("//*[@id=\"~6\"]"));
		act.moveToElement(d).click().build().perform();
		driver.findElement(By.xpath("//*[@id=\"cjaInd\"]")).click();
		WebElement e =driver.findElement(By.xpath("//*[@id=\"ul_indCja\"]/div/div[1]/ul/li[34]/a"));
		act.moveToElement(e).click().build().perform();
		driver.findElement(By.xpath("//*[@id=\"cjaJob\"]")).click();
		WebElement f =driver.findElement(By.xpath("//*[@id=\"ul_jcCja\"]/div/div[1]/ul/li[18]/a"));
		act.moveToElement(f).click().build().perform();
		driver.findElement(By.xpath("//*[@id=\"cjaRole\"]")).click();
		WebElement g =driver.findElement(By.xpath("//*[@id=\"ul_roleCja\"]/div/div[1]/ul/li[3]/a"));
		act.moveToElement(g).click().build().perform();
		driver.findElement(By.xpath("//*[@id=\"nyja\"]")).sendKeys("software developer jobs");
		driver.findElement(By.xpath("//*[@id=\"eml\"]")).sendKeys("venkataananthram@gmail.com");
	}
	public void createjobalert() {
		driver.findElement(By.xpath("//*[@id=\"cjaSubmit\"]")).click();
	}
}
